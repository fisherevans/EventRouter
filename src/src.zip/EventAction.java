import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
@Retention(RUNTIME)
@Target(value={METHOD})
public @interface EventAction {
    long value();
}
