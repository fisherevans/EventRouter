/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
public class EventActionLibrary {
    public static final long PLAYER_CREATED = 0;
}
