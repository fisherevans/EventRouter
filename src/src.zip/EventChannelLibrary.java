/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
public class EventChannelLibrary {
    public static final Long CAMERA_EVENTS = 0L;
}
