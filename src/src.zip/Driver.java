/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
public class Driver {
    public static void main(String[] args) {
        EventRouter.init();
        Camera camera = new Camera();
        EventRouter.send(EventChannelLibrary.CAMERA_EVENTS,
                EventActionLibrary.PLAYER_CREATED,
                "this is a string", new Long(9001), new Boolean(true));
    }
}
