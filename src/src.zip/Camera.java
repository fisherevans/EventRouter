/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
public class Camera {
    public Camera() {
        EventRouter.subscribe(this, EventChannelLibrary.CAMERA_EVENTS);
    }

    @EventAction(EventActionLibrary.PLAYER_CREATED)
    public void playerCreated(String test1, Long test2, Boolean test3) {
        System.out.println("Got player created event! " + test1 + " - " + test2 + " - " + test3);
    }
}
