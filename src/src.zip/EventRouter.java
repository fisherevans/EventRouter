import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Author: Fisher Evans
 * Date: 2/5/14
 */
public class EventRouter {
    public static final long CHANNEL_CAMERA = 0L;

    public static final Long ACTION_PLAYER_CREATED = 1000L;

    private static Map<Long, List<Object>> _registered;

    public static void init() {
        _registered = new HashMap<Long, List<Object>>();
    }

    public static void send(Long channelId, long actionId, Object ... args) {
        if(_registered.keySet().contains(channelId)) {
            for(Object obj:_registered.get(channelId)) {
                try {
                    for(Method method:obj.getClass().getMethods()) {
                        for(Annotation annotation:method.getAnnotations()) {
                            if(annotation instanceof EventAction) {
                                if(((EventAction) annotation).value() == actionId) {
                                    method.invoke(obj, args);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Error!!!");
                }
            }
        }
    }

    public static void subscribe(Object obj, Long channelId) {
        if(_registered.keySet().contains(channelId)) {
            List<Object> channel = _registered.get(channelId);
            if(!channel.contains(obj)) {
                channel.add(obj);
            }
        } else {
            List<Object> channel = new LinkedList<Object>();
            channel.add(obj);
            _registered.put(channelId, channel);
        }
    }

    public static void unSubscribe(Object obj, Long channelId) {
        if(_registered.keySet().contains(channelId)) {
            List<Object> channel = _registered.get(channelId);
            channel.remove(obj);
            if(channel.isEmpty()) {
                _registered.remove(channel);
            }
        }
    }
}
